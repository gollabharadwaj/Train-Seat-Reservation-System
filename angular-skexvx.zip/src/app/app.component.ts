import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  seatsToBook: number = 1;
  seats = [];
  totalSeats = 80;

  constructor() {
    this.initializeSeats();
  }

  // Initialize seat matrix (7 seats per row except the last row with 3 seats)
  initializeSeats() {
    let seatNumber = 1;
    for (let row = 0; row < 12; row++) {
      let currentRow = [];
      let seatsInRow = row === 11 ? 3 : 7;
      for (let col = 0; col < seatsInRow; col++) {
        currentRow.push({
          number: seatNumber,
          booked: false,
        });
        seatNumber++;
      }
      this.seats.push(currentRow);
    }
  }

  // Function to book seats
  bookSeats() {
    if (this.seatsToBook <= 0 || this.seatsToBook > 7) {
      alert('Please enter a valid number of seats (1-7)');
      return;
    }

    // Find and book seats
    const seatsBooked = this.findSeats(this.seatsToBook);

    if (seatsBooked.length > 0) {
      seatsBooked.forEach((seat) => (seat.booked = true));
      alert(`Booked seat number(s): ${seatsBooked.map((seat) => seat.number).join(', ')}`);
    } else {
      alert('Not enough adjacent seats available!');
    }
  }

  // Function to find and return available seats based on rules
  findSeats(seatsToBook) {
    let availableSeats = [];

    // First, try to book in the same row
    for (let row of this.seats) {
      const freeSeatsInRow = row.filter((seat) => !seat.booked);
      if (freeSeatsInRow.length >= seatsToBook) {
        return freeSeatsInRow.slice(0, seatsToBook); // Return the first 'n' seats in the same row
      }
    }

    // If no complete row, book adjacent seats across rows
    for (let row of this.seats) {
      for (let seat of row) {
        if (!seat.booked && availableSeats.length < seatsToBook) {
          availableSeats.push(seat);
        }
      }
      if (availableSeats.length === seatsToBook) {
        return availableSeats;
      }
    }

    return availableSeats; // Return available adjacent seats
  }
}
